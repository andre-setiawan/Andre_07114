package Guru.View;

import Guru.Controller.Dimas07146_GuruController;

public class Dimas07146_allobjctrl {
    public static Dimas07146_GuruController guru = new Dimas07146_GuruController();
}
