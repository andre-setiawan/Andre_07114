package Guru.Controller;

import Guru.Model.Dimas07146_GuruModel;

public class Dimas07146_AllObjectModel {
    public static Dimas07146_GuruModel guruModel = new Dimas07146_GuruModel();
}
