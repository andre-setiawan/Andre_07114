package Project;

import Staff.Controller.andre07114_AdminController;
import Staff.Controller.andre07114_DivisiController;
import Staff.Controller.andre07114_StaffController;
import Staff.Entity.andre07114_Staff;
import Staff.Model.andre07114_StaffModel;

import java.util.Scanner;

public class andre07114_Main {

    private andre07114_StaffController staffController = new andre07114_StaffController();
    private andre07114_AdminController adminController = new andre07114_AdminController();
    private andre07114_DivisiController divisiController = new andre07114_DivisiController();

    private andre07114_StaffModel staffModel   = new andre07114_StaffModel();
    private Scanner input;

    public static void main(String[] args) {
        andre07114_Main m = new andre07114_Main();
        m.menu();
    }

    public void menu() {
        input = new Scanner(System.in);
        int selectedMenu, npk, max;

        do {

            System.out.println("[1] view data");
            System.out.println("[2] add data");
            System.out.println("[3] upate data");
            System.out.println("[4] delete data");
            System.out.println("[7] Exit");
            System.out.print("Pilih menu> ");

            selectedMenu = input.nextInt();

            switch (selectedMenu) {
                case 1:
                    read();
                    break;
                case 2:
                    add();
                    break;
                case 3:
                    System.out.println("Masukan NPK: ");
                    npk = input.nextInt();

                    update(npk);
                    break;
                case 4:
                    System.out.println("Masukkan NPK: ");
                    npk = input.nextInt();

                    delete(npk);
                    break;
                case 5:
                    max = divisiController.maxData();
                    if(max > 0) {
                        System.out.println("------------------------------------");
                        System.out.println(" divisi / bagian : ");
                        System.out.println("------------------------------------");
                        for(int i = 0; i < max; i++) {
                            System.out.println("bagian: " + divisiController.view(i).getNama());
                            System.out.println("------------------------------------");
                        }
                    } else {
                        System.out.println("Data masih kosong");
                    }
                    break;
                case 6:
                    max = adminController.maxData();
                    if(max > 0) {
                        for(int i = 0; i < max; i++) {
                            System.out.println("Nama: " + adminController.view(i).getNama());
                        }
                    } else {
                        System.out.println("Data masih kosong");
                    }
                    break;
                case 7:
                    System.exit(0);
                default:
                    System.out.println("Anda salah memilih menu!");
            }
        } while(selectedMenu != 7);
    }

    public void add() {
        try {
            System.out.println("Masukan nama: ");
            String nama = input.next();
            System.out.println("Masukan divisi: ");
            String divisi = input.next();
            System.out.println("Masukan NPK: ");
            int npk = input.nextInt();
            String msg = staffController.insert(new andre07114_Staff(npk, nama, divisi));

            System.out.println(msg);
        } catch(Exception e) {
            System.out.println("Silahkan coba lagi.");
        }
    }

    public void read() {
        int max = staffController.maxData();
        if(max > 0) {
            System.out.println("Daftar Data Siswa:");
            for(int i = 0; i < max; i++) {
                System.out.println("Nama: " + staffController.view(i).getNama());
                System.out.println("NPK: " + staffController.view(i).getNpk());
                System.out.println("divisi: " + staffController.view(i).getDivisi());
            }
        } else {
            System.out.println("Data masih kosong");
        }
    }

    public void update(int npk) {
        int result = staffController.cekData(npk);

        if(result == -1) {
            System.out.println("Data masih kosong");
        } else if(result == -2) {
            System.out.println("Data tidak ditemukan / npk salah.");
        } else {
            andre07114_Staff staff = staffController.view(result);
            System.out.println("Nama: " + staff.getNama());
            System.out.println("NPK: " + staff.getNpk());
            System.out.println("Divisi: " + staff.getDivisi());

            System.out.println("Masukan nama: ");
            String nama = input.next();
            System.out.println("Masukan Divisi: ");
            String divisi = input.next();
            System.out.println("Masukan Npk: ");
            int npkBaru = input.nextInt();
            String msg = staffController.update(new andre07114_Staff(npkBaru, nama, divisi), staff.getNpk());
            System.out.println(msg);
        }
    }

    public void delete(int npk) {
        int result = staffModel.delete(npk);
        if(result != 0) {
            System.out.println("Gagal menghapus data");
        } else {
            System.out.println("Data berhasil terhapus");
        }
    }
}