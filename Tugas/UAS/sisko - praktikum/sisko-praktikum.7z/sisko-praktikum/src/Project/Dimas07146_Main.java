package Project;

import Guru.View.Dimas07146_GUI;

public class Dimas07146_Main {
    public static void main(String[] args) {
        Dimas07146_GUI gui = new Dimas07146_GUI();
    }
}
