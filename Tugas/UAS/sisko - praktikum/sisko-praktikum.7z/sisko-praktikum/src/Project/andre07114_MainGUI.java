package Project;

import Staff.GUI.andre07114_GUI;
import javax.swing.*;

public class andre07114_MainGUI extends JFrame {
    andre07114_GUI gui = new andre07114_GUI();
}