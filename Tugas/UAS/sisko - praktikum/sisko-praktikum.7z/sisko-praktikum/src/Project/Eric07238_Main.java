package Project;

import Murid.GUI.*;

/*
 * Main (Murid.Staff.GUI as default)
 * Will use Murid.Staff.GUI (Graphical User Interface) as a default.
 *
 * @author: Ericsson Budhilaw
 */

public class Eric07238_Main {
    Eric07238_GUI gui = new Eric07238_GUI();
}