package Staff.GUI;

import Staff.Controller.andre07114_AdminController;
import Staff.Controller.andre07114_DivisiController;
import Staff.Controller.andre07114_StaffController;

public class andre07114_AllObjctrl {
    public static andre07114_StaffController staff = new andre07114_StaffController();
    public static andre07114_DivisiController bagian = new andre07114_DivisiController();
    public static andre07114_AdminController admin = new andre07114_AdminController();
}
