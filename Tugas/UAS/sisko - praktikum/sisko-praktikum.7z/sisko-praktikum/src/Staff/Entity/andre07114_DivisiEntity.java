package Staff.Entity;

public class andre07114_DivisiEntity {
    public String nama, code;

    public andre07114_DivisiEntity(String nama, String code) {
        this.nama = nama;
        this.code = code;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
