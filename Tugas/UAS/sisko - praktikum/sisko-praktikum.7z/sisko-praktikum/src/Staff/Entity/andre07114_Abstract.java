package Staff.Entity;

public abstract class andre07114_Abstract {
    protected String nama;

    public andre07114_Abstract(String nama) {
        this.nama = nama;
    }

    public abstract String getNama();

    public void setNama(String nama) {
        this.nama = nama;
    }
}
