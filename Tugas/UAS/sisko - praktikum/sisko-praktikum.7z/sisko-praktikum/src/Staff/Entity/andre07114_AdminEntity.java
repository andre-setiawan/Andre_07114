package Staff.Entity;

public class andre07114_AdminEntity {
    private String nama, npk;

    public andre07114_AdminEntity(String nama, String npk) {
        this.nama = nama;
        this.npk = npk;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNpk() {
        return npk;
    }

    public void setNpk(String npk) {
        this.npk = npk;
    }
}

