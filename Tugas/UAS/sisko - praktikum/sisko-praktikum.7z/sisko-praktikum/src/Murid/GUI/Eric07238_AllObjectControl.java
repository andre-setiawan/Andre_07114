package Murid.GUI;

import Murid.Controller.Eric07238_AslabController;
import Murid.Controller.Eric07238_KelasController;
import Murid.Controller.Eric07238_SiswaController;

public class Eric07238_AllObjectControl {
    public static Eric07238_SiswaController siswa = new Eric07238_SiswaController();
    public static Eric07238_KelasController kelas = new Eric07238_KelasController();
    public static Eric07238_AslabController aslab = new Eric07238_AslabController();
}
